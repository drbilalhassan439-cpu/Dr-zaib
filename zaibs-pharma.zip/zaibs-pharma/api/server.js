// Zaib's Pharma — Secure Backend Proxy
// Keeps your Anthropic API key on the server, never exposed to the browser.
//
// Usage:
//   npm install express cors node-fetch
//   ANTHROPIC_API_KEY=sk-ant-... node api/server.js

const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: "2mb" }));

// Health check
app.get("/api/health", (req, res) => res.json({ status: "ok" }));

// Proxy route — frontend posts here, we forward to Anthropic
app.post("/api/chat", async (req, res) => {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "ANTHROPIC_API_KEY not set on server." });
  }

  try {
    // Dynamic import so this works with CommonJS
    const fetch = (await import("node-fetch")).default;

    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(req.body),
    });

    const data = await anthropicRes.json();

    if (!anthropicRes.ok) {
      return res.status(anthropicRes.status).json(data);
    }

    res.json(data);
  } catch (err) {
    console.error("Proxy error:", err);
    res.status(500).json({ error: err.message });
  }
});

// In production (Vercel), we export; locally we listen
if (process.env.NODE_ENV !== "production") {
  app.listen(PORT, () => {
    console.log(`✅ Zaib's Pharma proxy running on http://localhost:${PORT}`);
    console.log(`   API key loaded: ${process.env.ANTHROPIC_API_KEY ? "YES ✓" : "NO ✗ — set ANTHROPIC_API_KEY"}`);
  });
}

module.exports = app;
