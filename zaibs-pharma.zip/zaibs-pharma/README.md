# Zaib's Pharma 🌿⚕

AI-powered pharmacology advisor — prescriptions, natural remedies & warnings.

---

## 🚀 Option A — Run Locally with Backend Proxy

### 1. Install dependencies
```bash
npm install
npm install express cors node-fetch --prefix api   # or just: npm install express cors node-fetch
```

### 2. Set your API key
```bash
cp .env.example .env
# Edit .env and paste your Anthropic API key
```

### 3. Start the backend proxy (Terminal 1)
```bash
ANTHROPIC_API_KEY=sk-ant-... node api/server.js
```

### 4. Start the frontend (Terminal 2)
```bash
npm run dev
```

Open http://localhost:5173 — done! ✅

---

## 🌐 Option B — Deploy to Vercel (Recommended)

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Zaib's Pharma"
git remote add origin https://github.com/YOUR_USERNAME/zaibs-pharma.git
git push -u origin main
```

### 2. Import on Vercel
1. Go to https://vercel.com/new
2. Click **"Import Git Repository"**
3. Select your `zaibs-pharma` repo
4. Click **Deploy**

### 3. Add API key as Environment Variable
1. In Vercel dashboard → your project → **Settings → Environment Variables**
2. Add:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-your-key-here`
   - **Environment:** Production, Preview, Development ✓
3. Click **Save** → then **Redeploy**

Your app is now live at `https://zaibs-pharma.vercel.app` 🎉

---

## 🔑 Getting an Anthropic API Key

1. Go to https://console.anthropic.com
2. Sign up / log in
3. Go to **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`)

---

## 🔒 Security Notes

- Your API key lives **only on the server** — never in the browser
- The `/api/chat` route proxies requests securely
- `.env` is in `.gitignore` — never committed to Git
